package com.example.crud

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var viewModel: TaskViewModel
    private lateinit var adapter: TaskAdapter
    private lateinit var textGreeting: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[TaskViewModel::class.java]

        textGreeting = view.findViewById(R.id.textGreeting)
        val textTotalCount = view.findViewById<TextView>(R.id.textTotalCount)
        val textDueSoonCount = view.findViewById<TextView>(R.id.textDueSoonCount)
        val textSeeAll = view.findViewById<TextView>(R.id.textSeeAll)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerViewDueSoon)
        val layoutEmptyState = view.findViewById<View>(R.id.layoutEmptyState)
        val buttonEmptyAddTask = view.findViewById<Button>(R.id.buttonEmptyAddTask)

        updateGreeting()

        adapter = TaskAdapter(
            onPreviewClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.task_preview_title))
                    .setMessage(
                        "Title: ${task.title}\n\n" +
                                "Subject: ${task.subject}\n\n" +
                                "Description: ${task.description.ifEmpty { "(none)" }}\n\n" +
                                "Due: ${task.dueDate}"
                    )
                    .setPositiveButton("Close") { dialog, _ -> dialog.dismiss() }
                    .show()
            },
            onEditClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.home_edit_confirm_title))
                    .setMessage(getString(R.string.home_edit_confirm_message))
                    .setPositiveButton("Edit") { dialog, _ ->
                        dialog.dismiss()
                        val bundle = Bundle().apply { putInt("taskId", task.id) }
                        findNavController().navigate(R.id.addTaskFragment, bundle)
                    }
                    .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                    .show()
            },
            onDeleteClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Task")
                    .setMessage("Are you sure you want to delete \"${task.title}\"?")
                    .setPositiveButton("Delete") { dialog, _ ->
                        viewModel.deleteTask(task)
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                    .show()
            }
        )
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        viewModel.allTasks.observe(viewLifecycleOwner) { tasks ->
            textTotalCount.text = tasks.size.toString()
            textDueSoonCount.text = tasks.size.toString()

            val preview = tasks.take(3)
            adapter.setData(preview)

            val isEmpty = tasks.isEmpty()
            layoutEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
            recyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
        }

        textSeeAll.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.home_see_all_confirm_title))
                .setMessage(getString(R.string.home_see_all_confirm_message))
                .setPositiveButton("View") { dialog, _ ->
                    dialog.dismiss()
                    findNavController().navigate(R.id.pendingFragment)
                }
                .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                .show()
        }

        buttonEmptyAddTask.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.home_add_task_confirm_title))
                .setMessage(getString(R.string.home_add_task_confirm_message))
                .setPositiveButton("Continue") { dialog, _ ->
                    dialog.dismiss()
                    findNavController().navigate(R.id.addTaskFragment)
                }
                .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::textGreeting.isInitialized) {
            updateGreeting()
        }
    }

    private fun updateGreeting() {
        val prefs = requireContext().getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
        val name = prefs.getString("profile_name", "") ?: ""

        textGreeting.text = if (name.isNotBlank()) {
            getString(R.string.home_greeting_named, name)
        } else {
            getString(R.string.home_greeting)
        }
    }
}