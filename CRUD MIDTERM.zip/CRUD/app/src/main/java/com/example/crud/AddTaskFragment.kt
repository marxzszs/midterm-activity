package com.example.crud

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.crud.data.Task
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddTaskFragment : Fragment(R.layout.fragment_add_task) {

    private lateinit var viewModel: TaskViewModel
    private var editingTask: Task? = null // null = adding new, non-null = editing existing

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[TaskViewModel::class.java]

        val buttonBack = view.findViewById<ImageButton>(R.id.buttonBack)
        val editTitle = view.findViewById<EditText>(R.id.editTaskTitle)
        val editSubject = view.findViewById<EditText>(R.id.editTaskSubject)
        val editDueDate = view.findViewById<EditText>(R.id.editTaskDueDate)
        val editDescription = view.findViewById<EditText>(R.id.editTaskDescription)
        val btnSave = view.findViewById<Button>(R.id.buttonSaveTask)

        val taskId = arguments?.getInt("taskId", -1) ?: -1
        requireActivity().title = if (taskId != -1) "Edit Task" else "Add Task"

        // Open date picker when the due date field is tapped
        editDueDate.setOnClickListener {
            showDatePicker(editDueDate)
        }

        if (taskId != -1) {
            viewModel.allTasks.observe(viewLifecycleOwner) { tasks ->
                val task = tasks.find { it.id == taskId }
                if (task != null && editingTask == null) {
                    editingTask = task
                    editTitle.setText(task.title)
                    editSubject.setText(task.subject)
                    editDueDate.setText(task.dueDate)
                    editDescription.setText(task.description)
                }
            }
        }

        buttonBack.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.add_task_discard_title))
                .setMessage(getString(R.string.add_task_discard_message))
                .setPositiveButton("Go Back") { dialog, _ ->
                    dialog.dismiss()
                    findNavController().navigateUp()
                }
                .setNegativeButton("Stay") { dialog, _ -> dialog.dismiss() }
                .show()
        }

        btnSave.setOnClickListener {
            val title = editTitle.text.toString().trim()
            val subject = editSubject.text.toString().trim()
            val dueDate = editDueDate.text.toString().trim()
            val description = editDescription.text.toString().trim()

            if (title.isEmpty() || subject.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter a title and subject", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (dueDate.isEmpty()) {
                Toast.makeText(requireContext(), "Please select a due date", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val current = editingTask
            val confirmTitle = if (current != null)
                getString(R.string.add_task_update_confirm_title)
            else
                getString(R.string.add_task_save_confirm_title)
            val confirmMessage = if (current != null)
                getString(R.string.add_task_update_confirm_message)
            else
                getString(R.string.add_task_save_confirm_message)

            AlertDialog.Builder(requireContext())
                .setTitle(confirmTitle)
                .setMessage(confirmMessage)
                .setPositiveButton("Confirm") { dialog, _ ->
                    if (current != null) {
                        val updatedTask = current.copy(
                            title = title,
                            subject = subject,
                            description = description,
                            dueDate = dueDate
                        )
                        viewModel.updateTask(updatedTask)
                        Toast.makeText(requireContext(), "Task updated!", Toast.LENGTH_SHORT).show()
                    } else {
                        val task = Task(
                            title = title,
                            subject = subject,
                            description = description,
                            dueDate = dueDate
                        )
                        viewModel.addTask(task)
                        Toast.makeText(requireContext(), "Task saved successfully!", Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                    findNavController().navigate(R.id.homeFragment, null, androidx.navigation.navOptions {
                        popUpTo(R.id.homeFragment) { inclusive = false }
                        launchSingleTop = true
                    })
                }
                .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }

    private fun showDatePicker(targetField: EditText) {
        val calendar = Calendar.getInstance()

        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                calendar.set(year, month, dayOfMonth)
                targetField.setText(dateFormat.format(calendar.time))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).apply {
            datePicker.minDate = System.currentTimeMillis() - 1000 // prevent picking past dates
        }.show()
    }
}