package com.example.crud.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface TaskDao {

    // CREATE
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addTask(task: Task)

    // READ
    @Query("SELECT * FROM task_table ORDER BY id ASC")
    fun readAllTasks(): kotlinx.coroutines.flow.Flow<List<Task>>

    // UPDATE
    @Update
    suspend fun updateTask(task: Task)

    // DELETE
    @Delete
    suspend fun deleteTask(task: Task)

    // Bonus Delete All (useful during testing)
    @Query("DELETE FROM task_table")
    suspend fun deleteAllTasks()
}