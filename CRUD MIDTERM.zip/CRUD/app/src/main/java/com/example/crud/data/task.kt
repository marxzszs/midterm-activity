package com.example.crud.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "task_table")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,       // e.g., "Finish Tri-fold Brochure"
    val subject: String,     // e.g., "TTL1"
    val description: String, // e.g., "Include roles of tech in education"
    val dueDate: String      // We'll store dates as simple Strings for now
)