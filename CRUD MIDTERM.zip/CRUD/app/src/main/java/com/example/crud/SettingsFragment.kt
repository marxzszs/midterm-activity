package com.example.crud

import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.google.android.material.imageview.ShapeableImageView

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var viewModel: TaskViewModel
    private lateinit var imageProfilePhoto: ShapeableImageView
    private lateinit var textAvatarInitial: TextView

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                requireContext().contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: SecurityException) {
                // Some providers don't support persistable permissions
            }

            val prefs = requireContext().getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("profile_image_uri", uri.toString()).apply()

            showPhoto(uri)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[TaskViewModel::class.java]

        val prefs = requireContext().getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)

        val editProfileName = view.findViewById<EditText>(R.id.editProfileName)
        val buttonSaveName = view.findViewById<Button>(R.id.buttonSaveName)
        textAvatarInitial = view.findViewById(R.id.textAvatarInitial)
        imageProfilePhoto = view.findViewById(R.id.imageProfilePhoto)
        val buttonEditPhoto = view.findViewById<ImageButton>(R.id.buttonEditPhoto)
        val textProfileTotalCount = view.findViewById<TextView>(R.id.textProfileTotalCount)
        val buttonViewTasks = view.findViewById<Button>(R.id.buttonViewTasks)
        val buttonDeleteAllTasks = view.findViewById<Button>(R.id.buttonDeleteAllTasks)
        val editProfileBio = view.findViewById<EditText>(R.id.editProfileBio)
        val buttonSaveBio = view.findViewById<Button>(R.id.buttonSaveBio)

        // Name
        val savedName = prefs.getString("profile_name", "") ?: ""
        editProfileName.setText(savedName)
        updateAvatarInitial(savedName)

        // Bio
        val savedBio = prefs.getString("profile_bio", "") ?: ""
        editProfileBio.setText(savedBio)

        // Photo
        val savedPhotoUriString = prefs.getString("profile_image_uri", null)
        if (savedPhotoUriString != null) {
            showPhoto(Uri.parse(savedPhotoUriString))
        }

        buttonEditPhoto.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        buttonSaveName.setOnClickListener {
            val name = editProfileName.text.toString().trim()
            prefs.edit().putString("profile_name", name).apply()
            updateAvatarInitial(name)
            Toast.makeText(requireContext(), "Saved!", Toast.LENGTH_SHORT).show()
        }

        buttonSaveBio.setOnClickListener {
            val bio = editProfileBio.text.toString().trim()
            prefs.edit().putString("profile_bio", bio).apply()
            Toast.makeText(requireContext(), "Bio saved!", Toast.LENGTH_SHORT).show()
        }

        viewModel.allTasks.observe(viewLifecycleOwner) { tasks ->
            textProfileTotalCount.text = tasks.size.toString()
        }

        buttonViewTasks.setOnClickListener {
            findNavController().navigate(R.id.pendingFragment)
        }

        buttonDeleteAllTasks.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.profile_clear_confirm_title))
                .setMessage(getString(R.string.profile_clear_confirm_message))
                .setPositiveButton("Delete") { dialog, _ ->
                    viewModel.allTasks.value?.forEach { task ->
                        viewModel.deleteTask(task)
                    }
                    dialog.dismiss()
                    Toast.makeText(requireContext(), "All tasks deleted", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }

    private fun updateAvatarInitial(name: String) {
        textAvatarInitial.text = if (name.isNotBlank()) name.first().uppercase() else "?"
    }

    private fun showPhoto(uri: Uri) {
        try {
            imageProfilePhoto.setImageURI(uri)
            imageProfilePhoto.visibility = View.VISIBLE
            textAvatarInitial.visibility = View.GONE
        } catch (e: Exception) {
            imageProfilePhoto.visibility = View.GONE
            textAvatarInitial.visibility = View.VISIBLE
        }
    }
}