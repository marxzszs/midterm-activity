package com.example.crud

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.crud.data.Task

class TaskAdapter(
    private val onPreviewClick: (Task) -> Unit,
    private val onEditClick: (Task) -> Unit,
    private val onDeleteClick: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    private var taskList = emptyList<Task>()

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.textTaskTitle)
        val subject: TextView = itemView.findViewById(R.id.textSubject)
        val dueDate: TextView = itemView.findViewById(R.id.textDueDate)
        val previewButton: ImageButton = itemView.findViewById(R.id.buttonPreviewTask)
        val editButton: ImageButton = itemView.findViewById(R.id.buttonEditTask)
        val deleteButton: ImageButton = itemView.findViewById(R.id.buttonDeleteTask)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val currentItem = taskList[position]
        holder.title.text = currentItem.title
        holder.subject.text = currentItem.subject
        holder.dueDate.text = currentItem.dueDate

        holder.previewButton.setOnClickListener { onPreviewClick(currentItem) }
        holder.editButton.setOnClickListener { onEditClick(currentItem) }
        holder.deleteButton.setOnClickListener { onDeleteClick(currentItem) }
    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    fun setData(tasks: List<Task>) {
        this.taskList = tasks
        notifyDataSetChanged()
    }
}