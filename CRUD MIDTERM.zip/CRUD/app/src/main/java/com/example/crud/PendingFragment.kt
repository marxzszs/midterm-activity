package com.example.crud

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class PendingFragment : Fragment(R.layout.fragment_pending) {

    private lateinit var viewModel: TaskViewModel
    private lateinit var adapter: TaskAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[TaskViewModel::class.java]

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerViewTasks)
        adapter = TaskAdapter(
            onPreviewClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.task_preview_title))
                    .setMessage(
                        "Title: ${task.title}\n\n" +
                                "Subject: ${task.subject}\n\n" +
                                "Description: ${task.description.ifEmpty { "(none)" }}\n\n" +
                                "Due: ${task.dueDate}"
                    )
                    .setPositiveButton("Close") { dialog, _ -> dialog.dismiss() }
                    .show()
            },
            onEditClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.pending_edit_confirm_title))
                    .setMessage(getString(R.string.pending_edit_confirm_message))
                    .setPositiveButton("Edit") { dialog, _ ->
                        dialog.dismiss()
                        val bundle = Bundle().apply { putInt("taskId", task.id) }
                        findNavController().navigate(R.id.action_pendingFragment_to_addTaskFragment, bundle)
                    }
                    .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                    .show()
            },
            onDeleteClick = { task ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Task")
                    .setMessage("Are you sure you want to delete \"${task.title}\"?")
                    .setPositiveButton("Delete") { dialog, _ ->
                        viewModel.deleteTask(task)
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                    .show()
            }
        )
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        viewModel.allTasks.observe(viewLifecycleOwner) { tasks ->
            adapter.setData(tasks)
        }

        val fab = view.findViewById<FloatingActionButton>(R.id.fabAddTask)
        fab.setOnClickListener {
            // Confirm before jumping into Add Task, for consistency with Edit/Delete
            AlertDialog.Builder(requireContext())
                .setTitle("Add New Task?")
                .setMessage("Go to the Add Task screen?")
                .setPositiveButton("Continue") { dialog, _ ->
                    dialog.dismiss()
                    findNavController().navigate(R.id.action_pendingFragment_to_addTaskFragment)
                }
                .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }
}